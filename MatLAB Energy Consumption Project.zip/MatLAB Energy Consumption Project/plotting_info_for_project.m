Pop = readmatrix('Final_Project_Populations.txt');

Years = Pop(1,:);
% Japan = Pop(2,:);
%  Kenya = Pop(3,:);
%  Brazil = Pop(4,:);
% Belgium = Pop(5,:);
% Togo = Pop(6,:);
% United_Kingdom = Pop(7,:);
% United_States = Pop (8,:);
% Nepal = Pop(9,:);

Elec = readmatrix('Electricity_Consumption.txt');

JapanE = Elec(1,:);
KenyaE = Elec(2,:);
BrazilE = Elec(3,:);
BelgiumE = Elec(4,:);
TogoE = Elec(5,:);
United_KingdomE = Elec(6,:);
United_StatesE = Elec(7,:);
NepalE = Elec(8,:);
% 
% Other = readmatrix('Other_Energy_Consumption.txt');
% 
% Japan_Coal = Other(1,1);
% Japan_Petroleum = Other(1,2);
% Japan_Natural_Gas = Other(1,3);
% Japan_Renewable_Energy = Other(1,4);
% Kenya_Coal = Other(2,1);
% Kenya_Petroleum = Other(2,2);
% Kenya_Natural_Gas = Other(2,3);
% Kenya_Renewable_Energy = Other(2,4);
% Brazil_Coal = Other(3,1);
% Brazil_Petroleum = Other(3,2);
% Brazil_Natural_Gas = Other(3,3);
% Brazil_Renewable_Energy = Other(3,4);
% Belgium_Coal = Other(4,1);
% Belgium_Petroleum = Other(4,2);
% Belgium_Natural_Gas = Other(4,3);
% Belgium_Renewable_Energy = Other(4,4);
% Togo_Coal = Other(5,1);
% Togo_Petroleum = Other(5,2);
% Togo_Natural_Gas = Other(5,3);
% Togo_Renewable_Energy = Other(5,4);
% United_Kingdom_Coal = Other(6,1);
% United_Kingdom_Petroleum = Other(6,2);
% United_Kingdom_Natural_Gas = Other(6,3);
% United_Kingdom_Renewable_Energy = Other(6,4);
% United_States_Coal = Other(7,1);
% United_States_Petroleum = Other(7,2);
% United_States_Natural_Gas = Other(6,3);
% United_States_Renewable_Energy = Other(6,4);
% Nepal_Coal = Other(8,1);
% Nepal_Petroleum = Other(8,2);
% Nepal_Natural_Gas = Other(8,3);
% Nepal_Renewable_Energy = Other(8,4);


% plot(Years,Brazil,'g-');
% hold on;
% plot(Years,Belgium,'b-');
% plot(Years,Japan,'r-');
% plot(Years,Kenya,'c-');
% plot(Years,Togo,'y-');
% plot(Years,United_Kingdom,'m-');
% plot(Years,United_States,'g-.');
% plot(Years, Nepal,'b-.');
% hold off;
% title('country populations over time', 'FontSize',14);
% xlabel('year','FontSize',12);
% ylabel('populations (in numbers of people)','FontSize',12);
% legend('Brazil','Belgium','Japan','Kenya','Togo','United Kingdom','United States','Nepal','Location','northwest','Orientation','vertical');


bar(Years,JapanE);
title('Japan energy usage over time');
xlabel('year');
ylabel('energy consumption (in billion kWh/year)');

bar(Years,KenyaE);
title('Kenya energy usage over time');
xlabel('year');
ylabel('energy consumption (in billion kWh/year)');

bar(Years,BrazilE);
title('Brazil energy usage over time');
xlabel('year');
ylabel('energy consumption (in billion kWh/year)');

bar(Years,BelgiumE);
title('Belgium energy usage over time');
xlabel('year');
ylabel('energy consumption (in billion kWh/year)');

bar(Years,TogoE);
title('Togo energy usage over time');
xlabel('year');
ylabel('energy consumption (in billion kWh/year)');

bar(Years,United_KingdomE);
title('United Kingdom energy usage over time');
xlabel('year');
ylabel('energy consumption (in billion kWh/year)');

bar(Years,United_StatesE);
title('United States energy usage over time');
xlabel('year');
ylabel('energy consumption (in billion kWh/year)');

bar(Years,NepalE);
title('Nepal energy usage over time');
xlabel('year');
ylabel('energy consumption (in billion kWh/year)');